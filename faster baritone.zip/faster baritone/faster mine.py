import subprocess
import sys
import random

def install_dependencies():
    try:
        import pynput
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pynput"], 
                              creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0)

install_dependencies()

import tkinter as tk
from pynput import mouse, keyboard
import threading

m = mouse.Controller()
config = {
    "start": keyboard.Key.insert, 
    "stop": ".", 
    "is_setting_start": False, 
    "is_setting_stop": False
}

def get_key_name(key):
    if hasattr(key, 'char') and key.char is not None:
        return key.char.upper()
    return str(key).replace("Key.", "").capitalize()

def on_p(key):
    if config["is_setting_start"]:
        config["start"] = key
        config["is_setting_start"] = False
        update_status_text()
        return
    if config["is_setting_stop"]:
        config["stop"] = key.char if hasattr(key, 'char') else key
        config["is_setting_stop"] = False
        update_status_text()
        return
    
    if key == config["start"]:
        m.press(mouse.Button.left)
    
    current_stop = config["stop"]
    if (hasattr(key, 'char') and key.char == current_stop) or key == current_stop:
        m.release(mouse.Button.left)

threading.Thread(target=lambda: keyboard.Listener(on_press=on_p).start(), daemon=True).start()

root = tk.Tk()
root.title("Faster Baritone")
root.geometry("400x600")
root.configure(bg="#050505")
root.attributes('-topmost', True)
root.resizable(False, False)

bg_canvas = tk.Canvas(root, width=400, height=600, bg="#050505", highlightthickness=0)
bg_canvas.place(x=0, y=0)

lines = []

def create_moving_line():
    is_horizontal = random.choice([True, False])
    color = random.choice(["#00f2ff", "#0055ff", "#002244"])
    
    if is_horizontal:
        y = random.randint(0, 600)
        line = bg_canvas.create_line(-50, y, 0, y, fill=color, width=1)
        speed = (random.randint(2, 5), 0)
    else:
        x = random.randint(0, 400)
        line = bg_canvas.create_line(x, -50, x, 0, fill=color, width=1)
        speed = (0, random.randint(2, 5))
    
    lines.append((line, speed))
    root.after(random.randint(400, 800), create_moving_line)

def update_lines():
    for i in range(len(lines) - 1, -1, -1):
        line, speed = lines[i]
        bg_canvas.move(line, speed[0], speed[1])
        pos = bg_canvas.coords(line)
        if pos[0] > 450 or pos[1] > 650:
            bg_canvas.delete(line)
            lines.pop(i)
    root.after(30, update_lines)

create_moving_line()
update_lines()

title_font = ("Courier New", 26, "bold")
btn_font = ("Segoe UI", 10, "bold")
status_font = ("Consolas", 11)

tk.Label(root, text="FASTER BARITONE", font=title_font, fg="#00f2ff", bg="#050505").pack(pady=(40, 10))

status_label = tk.Label(root, text="", font=status_font, fg="#008b8b", bg="#050505")
status_label.pack(pady=5)

def update_status_text():
    start_key = get_key_name(config["start"])
    stop_key = get_key_name(config["stop"])
    status_label.config(text=f"START: [{start_key}] | STOP: [{stop_key}]")

update_status_text()

def popup(title, text):
    win = tk.Toplevel(root)
    win.title(title)
    win.geometry("350x250")
    win.configure(bg="#0a0a0a")
    win.attributes('-topmost', True)
    tk.Label(win, text=text, fg="#00f2ff", bg="#0a0a0a", justify="center", font=("Segoe UI", 10), wraplength=300).pack(expand=True)

btn_style = {"bg": "#111111", "fg": "#00f2ff", "activebackground": "#00f2ff", "relief": "flat", "font": btn_font, "width": 22, "pady": 10}

tk.Button(root, text="HOW TO USE", command=lambda: popup("Manual", "Get on MC, open Faster Baritone!\n\nACTIVATE AUTO MINER FIRST!"), **btn_style).pack(pady=10)
tk.Button(root, text="DIFFRENCE", command=lambda: popup("Stats", "Normal Baritone: 50% Speed\nFaster Baritone: 80% Speed"), **btn_style).pack(pady=10)
tk.Button(root, text="KEYBINDS", command=lambda: popup("Keybind Settings", "Click START or STOP in the keybind menu to re-assign."), **btn_style).pack(pady=10)
tk.Button(root, text="DEV", command=lambda: popup("Dev Info", "DEV: MelonGG3\nTikTok: melon_.gg3"), **btn_style).pack(pady=10)

tk.Frame(root, height=3, bg="#00f2ff").pack(fill="x", side="bottom")

root.mainloop()